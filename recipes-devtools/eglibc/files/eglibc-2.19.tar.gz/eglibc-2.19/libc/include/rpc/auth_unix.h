#include <sunrpc/rpc/auth_unix.h>

libc_hidden_proto (xdr_authunix_parms)
