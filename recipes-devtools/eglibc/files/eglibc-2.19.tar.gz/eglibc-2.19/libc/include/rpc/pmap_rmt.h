#include <sunrpc/rpc/pmap_rmt.h>

libc_hidden_proto (xdr_rmtcall_args)
libc_hidden_proto (xdr_rmtcallres)
