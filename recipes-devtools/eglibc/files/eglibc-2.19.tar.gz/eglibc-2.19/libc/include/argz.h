#ifndef _ARGZ_H

#include <string/argz.h>

libc_hidden_proto (argz_delete)
libc_hidden_proto (__argz_count)
libc_hidden_proto (__argz_stringify)

#endif
