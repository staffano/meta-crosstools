#ifndef _WORDEXP_H

#include <posix/wordexp.h>

#ifndef _ISOMAC
libc_hidden_proto (wordfree)
#endif

#endif
