/* No floating-point inline functions in rtld.  */
#ifndef IS_IN_rtld
# include <stdlib/bits/stdlib-float.h>
#endif
