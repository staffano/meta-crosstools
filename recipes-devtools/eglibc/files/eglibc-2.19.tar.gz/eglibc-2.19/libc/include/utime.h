#ifndef _UTIME_H

#include <io/utime.h>

#ifndef _ISOMAC
libc_hidden_proto (utime)
#endif

#endif /* utime.h */
