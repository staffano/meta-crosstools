#ifndef _FNMATCH_H

#include <posix/fnmatch.h>

#ifndef _ISOMAC
libc_hidden_proto (fnmatch)
#endif

#endif
