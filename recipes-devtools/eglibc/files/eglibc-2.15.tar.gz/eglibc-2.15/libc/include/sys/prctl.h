#ifndef _SYS_PRCTL_H
#include_next <sys/prctl.h>

extern int __prctl (int __option, ...);

#endif
