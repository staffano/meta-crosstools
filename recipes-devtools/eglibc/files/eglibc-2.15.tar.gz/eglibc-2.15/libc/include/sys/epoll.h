#ifndef _SYS_EPOLL_H
#include_next <sys/epoll.h>

libc_hidden_proto (epoll_pwait)

#endif
