#ifndef _PTY_H
#include <login/pty.h>

libutil_hidden_proto (openpty)

#endif
