#ifndef _FNMATCH_H

#include <posix/fnmatch.h>

libc_hidden_proto (fnmatch)

#endif
