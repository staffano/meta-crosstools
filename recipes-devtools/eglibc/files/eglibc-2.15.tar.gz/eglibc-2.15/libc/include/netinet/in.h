#ifndef _NETINET_IN_H

#include <inet/netinet/in.h>

libc_hidden_proto (bindresvport)
libc_hidden_proto (in6addr_loopback)
libc_hidden_proto (in6addr_any)

#endif
