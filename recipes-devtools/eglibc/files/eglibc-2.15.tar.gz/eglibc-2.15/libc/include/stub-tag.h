/* This header is included into every file that declares a stub function.
   It is obsolete now, but hasn't died to avoid removing all those
   #include's.  Every such file should use the `stub_warning' macro for
   each of its functions, and that is sufficient.  */
