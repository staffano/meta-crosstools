#include <sunrpc/rpc/key_prot.h>

libc_hidden_proto (xdr_cryptkeyarg)
libc_hidden_proto (xdr_cryptkeyarg2)
libc_hidden_proto (xdr_cryptkeyres)
libc_hidden_proto (xdr_key_netstarg)
libc_hidden_proto (xdr_key_netstres)
libc_hidden_proto (xdr_keybuf)
libc_hidden_proto (xdr_keystatus)
libc_hidden_proto (xdr_getcredres)
libc_hidden_proto (xdr_netnamestr)
libc_hidden_proto (xdr_unixcred)
