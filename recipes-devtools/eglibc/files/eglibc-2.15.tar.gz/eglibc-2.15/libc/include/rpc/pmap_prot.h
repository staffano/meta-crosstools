#include <sunrpc/rpc/pmap_prot.h>

libc_hidden_proto (xdr_pmap)
libc_hidden_proto (xdr_pmaplist)
