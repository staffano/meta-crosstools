#include <rt/mqueue.h>

#ifdef IS_IN_librt
hidden_proto (mq_timedsend)
hidden_proto (mq_timedreceive)
hidden_proto (mq_setattr)
#endif
