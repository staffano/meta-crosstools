/* open64 is defined in open.c as an alias.  */
